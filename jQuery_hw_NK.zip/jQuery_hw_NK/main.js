/*Create a Checklist: Independent Practice
You'll add the ability to complete tasks in the list. Your program must complete the following rules:
- Through jQuery add a "complete task" link at the end of each to-do item.
- When clicked, the link will cross out the current task (hint: add a class to the list that sets the text-decoration to strikeout).
- Each new task added by the user needs to also have the "complete task" link akt the end.
- Bonus: when user completes task, remove the task from the current list and add it to a completed list below. Do not show this list unless the there are completed items.
- Bonus 2: add the ability to restore items from the completed list to the first list.
*/

/*
'use strict';

var MyApp = {};

MyApp.addToList = function(list) {
  var $newLi = $('<li>');
  var $newItemText = $('#new-thing');
  $newLi.html($newItemText.val());
  $newItemText.val('');
  if ($newLi.html() !== '') {
    list.append($newLi);
  }
}
*/




//ask the user's name
//var userName = prompt('What is your name?');
//put the user's name on the span with #name
//$('#name').html(userName);

/*
var $todoList = $("todo-list");

var $button = $("#newItemButton");

var $newItem = $("#newItem").val();


//when the user clicks on the 'add' button append list items to ul with #todo-list
$button.on('click', function() {
	$('#todo-list').append().html('<li><input id="checkbox" type="checkbox"><span></span></li>');
});

/*



/*

MyApp.addToList = function(list) {
  var $newLi = $('<li>');
  var $newItemText = $('#new-thing');

  $newLi.html($('#new-thing').val());
  
  $newItemText.val('');
  if ($newLi.html() !== '') {
    list.append($newLi);
  }
}
*/

//avoid global variables
//strive to make functions reusable
//

/*
function addnewItem(list, itemText) {
	var listItem = document.createElement("li");
	listItem.innerText = itemText;

	list.appendChild(listItem);
}

var inItemText = document.getElementById("newItem");
inItemText.focus();
inItemText.onkeyup = submitItem;
//btnNew.onclick = submitItem;

var btnNew = document.getElementById("btnAdd");

function submitItem() {

	var itemText = inItemText.value;

	if (!itemText || itemText == " ") {
		return false;
	}
	addNewItem(document.getElementById("todo-list"), itemText);
};
*/





















//var userName = prompt('What is your name?');
//$('#name').html(userName);


(function() {
	$("#newItemButton").on('click', addListItem);
})();

function addListItem() {
	var text = $("#newItem").val();
	$("#todo-list").append('<li><input id="checkbox" type="checkbox"><span>' + text + '</span></li>');
};






















